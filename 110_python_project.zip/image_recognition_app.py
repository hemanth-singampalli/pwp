from tensorflow.keras.applications.mobilenet import MobileNet, preprocess_input, decode_predictions
from tensorflow.keras.preprocessing import image
import numpy as np

# ------------------------------------------------------------
# Load pre-trained MobileNet model
# ------------------------------------------------------------
model = MobileNet(weights="imagenet")

# ------------------------------------------------------------
# Function to recognize image
# ------------------------------------------------------------
def recognize_image(img_path):
    print("\nLoading image:", img_path)

    # Load image with target size
    img = image.load_img(img_path, target_size=(224, 224))

    # Convert image to array
    img_array = image.img_to_array(img)

    # Expand dimensions for model input
    img_array = np.expand_dims(img_array, axis=0)

    # Preprocess image
    img_array = preprocess_input(img_array)

    # Predict
    predictions = model.predict(img_array)

    # Decode prediction (Top 1 result)
    result = decode_predictions(predictions, top=1)[0][0]

    object_name = result[1]
    accuracy = round(result[2] * 100, 2)

    print(f"\nRecognized Object: {object_name}")
    print(f"Accuracy: {accuracy}%")

# ------------------------------------------------------------
# RUN CODE
# ------------------------------------------------------------
# FIXED FILE PATH (raw string)
image_path = r"C:\Users\HP\OneDrive\Documents\python project 110\car bike.jpg"
recognize_image(image_path)
