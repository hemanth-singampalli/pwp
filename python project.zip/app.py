from torchvision import models, transforms
from PIL import Image

# Use one of the three options above
image_path =r"C:\Users\naray\OneDrive\Desktop\Imagerecognition app\pexels-mikebirdy-116675.jpg"

image = Image.open(image_path)
image.show()
print("Image opened successfully!")

image = Image.open(image_path)
image.show()


# Load pre-trained ResNet50 model
model = models.resnet50(weights=models.ResNet50_Weights.DEFAULT)
model.eval()

# Labels for ImageNet dataset
weights = models.ResNet50_Weights.DEFAULT
categories = weights.meta["categories"]

# Image preprocessing
preprocess = transforms.Compose([
    transforms.Resize(256),
    transforms.CenterCrop(224),
    transforms.ToTensor(),
    transforms.Normalize(
        mean=[0.485, 0.456, 0.406],
        std=[0.229, 0.224, 0.225]
    )
])

# Open and process image
image = Image.open(image_path)
batch = preprocess(image).unsqueeze(0)

# Run prediction
with torch.no_grad():
    prediction = model(batch).squeeze(0).softmax(0)

# Get top 1 result
class_id = prediction.argmax().item()
score = prediction[class_id].item()
category_name = categories[class_id]

print(f"This looks like a {category_name} ({score:.2%} confidence)")
